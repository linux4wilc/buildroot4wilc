#!/bin/sh

autoreconf -f -i
