# Version number and release date.
VERSION_NUMBER=0.18.3
RELEASE_DATE=2013-07-07      # in "date +%Y-%m-%d" format
