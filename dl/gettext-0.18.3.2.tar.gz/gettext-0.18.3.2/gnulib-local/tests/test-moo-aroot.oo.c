#include <config.h>

/* Specification.  */
#include "test-moo-aroot.h"

#pragma implementation
