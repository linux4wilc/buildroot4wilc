#include "test-moo-root.h"

#include <stdio.h>

/* Define a subclass.  */
struct sub1 : struct root
{
  FILE *fp;
methods:
};
