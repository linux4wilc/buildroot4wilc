#ifndef LIBCROCO_VERSION_NUMBER
#define LIBCROCO_VERSION_NUMBER 601
#endif

#ifndef LIBCROCO_VERSION
#define LIBCROCO_VERSION "0.6.1"
#endif

#ifndef G_DISABLE_CHECKS
#if 0
#define G_DISABLE_CHECKS 0
#endif
#endif

#if 1
#define CROCO_HAVE_LIBXML2 1
#endif

